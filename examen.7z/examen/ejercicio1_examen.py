print ("programa para calcular la suma de los digitos ingresados")
n1= int (input("Ingrese un numero"))
n2= int (input("Ingrese otro numero"))

result = n1 + n2
print ("La suma es:", result)