print ("Programa para calcular el area de un triangulo")
base = int(input("Ingrese la base del triangulo"))
altura = int(input("Ingrese la altura del triangulo"))

result = base * altura /2
print ("El area de su triangulo es:", result) 
    